import heapq  # Requirement: For Max-Heap Priority
import json   # Requirement: For File Handling

# DATA STRUCTURE 1: LINKED LIST NODE
# Used to store patient records dynamically
class PatientNode:
    def __init__(self, p_id, name, stage, diagnosis):
        self.p_id = p_id
        self.name = name
        self.stage = int(stage)  # Cancer Stage (1-4)
        self.diagnosis = diagnosis
        self.next = None

class LungCancerManagement:
    def __init__(self):
        # Initializing the three major data structures required
        self.head = None  # Linked List for general records
        self.search_map = {}  # DATA STRUCTURE 2: HASH TABLE for O(1) Search
        self.priority_queue = []  # DATA STRUCTURE 3: MAX-HEAP for priority
        self.file_name = "cancer_database.json"

    # OPERATION: INSERTION
    def add_patient(self, p_id, name, stage, diagnosis):
        new_node = PatientNode(p_id, name, stage, diagnosis)
        
        # 1. Insert into Linked List (at the beginning)
        new_node.next = self.head
        self.head = new_node
        
        # 2. Insert into Hash Table for efficient lookup
        self.search_map[p_id] = new_node
        
        # 3. Insert into Max-Heap for priority based on Cancer Stage
        # (We use negative stage because Python's heapq is a min-heap by default)
        heapq.heappush(self.priority_queue, (-int(stage), p_id, name))
        print(f"\n[Success] Patient {name} registered successfully.")

    # OPERATION: EFFICIENT SEARCH
    def search_patient(self, p_id):
        # Justification: Hash Table provides O(1) time complexity for searching
        patient = self.search_map.get(p_id)
        if patient:
            print(f"\n--- Patient Record Found ---")
            print(f"ID: {patient.p_id} | Name: {patient.name} | Stage: {patient.stage}")
            print(f"Diagnosis: {patient.diagnosis}")
        else:
            print("\n[Error] No record found for the provided ID.")

    # OPERATION: DELETE
    def delete_patient(self, p_id):
        if p_id in self.search_map:
            # Remove from Hash Table
            del self.search_map[p_id]
            
            # Remove from Linked List
            curr = self.head
            prev = None
            while curr:
                if curr.p_id == p_id:
                    if prev: prev.next = curr.next
                    else: self.head = curr.next
                    break
                prev = curr
                curr = curr.next
            print(f"\n[Deleted] Record with ID {p_id} has been removed.")
        else:
            print("\n[Error] Record not found.")

    # OPERATION: DISPLAY
    def display_all(self):
        """Sequential display of all patients using the Linked List"""
        print("\n--- ALL PATIENTS (Linked List) ---")
        curr = self.head
        if not curr: print("No records available.")
        while curr:
            print(f"ID: {curr.p_id} | Name: {curr.name} | Stage: {curr.stage}")
            curr = curr.next

    def display_priority(self):
        """Level order priority display using the Max-Heap"""
        print("\n--- EMERGENCY PRIORITY QUEUE (Max-Heap) ---")
        # Sorting for display purposes to show highest stage first
        for s, pid, name in sorted(self.priority_queue):
            print(f"Priority Level (Stage): {-s} | Patient: {name} | ID: {pid}")

    # FILE HANDLING
    def save_data(self):
        data = []
        curr = self.head
        while curr:
            data.append({'id': curr.p_id, 'name': curr.name, 'stage': curr.stage, 'diag': curr.diagnosis})
            curr = curr.next
        with open(self.file_name, 'w') as f:
            json.dump(data, f)
        print("\n[System] Data saved to cancer_database.json.")

    def load_data(self):
        try:
            with open(self.file_name, 'r') as f:
                records = json.load(f)
                for r in records:
                    self.add_patient(r['id'], r['name'], r['stage'], r['diag'])
            print("[System] Previous records loaded.")
        except FileNotFoundError:
            print("[System] No previous data found. Starting fresh.")

# MENU-DRIVEN INTERFACE
def main():
    system = LungCancerManagement()
    system.load_data()
    
    while True:
        print("\n" + "="*35)
        print(" LUNG CANCER HEALTH SYSTEM MENU ")
        print("="*35)
        print("1. Register New Patient")
        print("2. Search Patient by ID")
        print("3. Delete Patient Record")
        print("4. Display All Records (List)")
        print("5. View Emergency Priority (Heap)")
        print("6. Save & Exit")
        
        choice = input("\nEnter choice (1-6): ")
        
        if choice == '1':
            p_id = input("Enter ID: ")
            name = input("Enter Name: ")
            stage = input("Enter Cancer Stage (1-4): ")
            diag = input("Enter Diagnosis Details: ")
            system.add_patient(p_id, name, stage, diag)
        elif choice == '2':
            system.search_patient(input("Enter Patient ID to search: "))
        elif choice == '3':
            system.delete_patient(input("Enter Patient ID to delete: "))
        elif choice == '4':
            system.display_all()
        elif choice == '5':
            system.display_priority()
        elif choice == '6':
            system.save_data()
            print("Exiting System. Goodbye!")
            break
        else:
            print("Invalid Choice! Please try again.")

if __name__ == "__main__":
    main()